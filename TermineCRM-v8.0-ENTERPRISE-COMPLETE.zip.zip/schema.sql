-- TermineCRM v8.0 Enterprise Database Schema
-- Version: 8.0 Enterprise
-- Date: 2025-10-16
-- Features: Abteilungsspezifische Formulare, Familienmitglieder, Erweiterte KPIs

-- ====================================================================
-- WICHTIGER HINWEIS:
-- Diese Datei dient nur zur REFERENZ des Datenbankschemas.
-- Die Tabellen werden automatisch über die API erstellt.
-- NICHT direkt in D1 ausführen - würde bestehende Daten löschen!
-- ====================================================================

-- 1. DEPARTMENTS (Abteilungen)
-- Definiert Versicherung und Telekommunikation
CREATE TABLE departments (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL UNIQUE,
    color TEXT NOT NULL DEFAULT '#3b82f6',
    icon TEXT DEFAULT 'fas fa-building',
    description TEXT,
    is_active INTEGER DEFAULT 1,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Standard-Abteilungen
INSERT INTO departments (name, color, icon, description) VALUES 
('Versicherung', '#3b82f6', 'fas fa-shield-alt', 'Kranken-, Auto-, Lebensversicherung'),
('Telekommunikation', '#8b5cf6', 'fas fa-phone', 'Telekom-Services und Verträge');

-- 2. TEAMS (Teams pro Abteilung)
CREATE TABLE teams (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    department_id INTEGER NOT NULL,
    team_leader_id INTEGER,
    monthly_target INTEGER DEFAULT 0,
    color TEXT DEFAULT '#3b82f6',
    description TEXT,
    is_active INTEGER DEFAULT 1,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (department_id) REFERENCES departments(id),
    FOREIGN KEY (team_leader_id) REFERENCES users(id)
);

-- 3. USERS (Benutzer mit erweiterten Rollen)
CREATE TABLE users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    username TEXT NOT NULL UNIQUE,
    email TEXT UNIQUE,
    password_hash TEXT NOT NULL,
    role TEXT NOT NULL DEFAULT 'agent',
    department_id INTEGER,
    team_id INTEGER,
    phone TEXT,
    monthly_target INTEGER DEFAULT 0,
    is_active INTEGER DEFAULT 1,
    last_login DATETIME,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (department_id) REFERENCES departments(id),
    FOREIGN KEY (team_id) REFERENCES teams(id)
);

-- 4. SESSIONS (Login-Sessions)
CREATE TABLE sessions (
    id TEXT PRIMARY KEY,
    user_id INTEGER NOT NULL,
    expires_at DATETIME NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    last_accessed DATETIME DEFAULT CURRENT_TIMESTAMP,
    user_agent TEXT,
    ip_address TEXT,
    FOREIGN KEY (user_id) REFERENCES users(id)
);

-- 5. APPOINTMENTS (Erweiterte Termine-Tabelle)
-- Unterstützt BEIDE Abteilungen mit abteilungsspezifischen Feldern
CREATE TABLE appointments (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    agent_id INTEGER NOT NULL,
    created_by_id INTEGER NOT NULL,
    team_id INTEGER,
    department_id INTEGER NOT NULL,

    -- BASIS-FELDER (beide Abteilungen)
    date DATE NOT NULL,
    time TIME NOT NULL,
    customer_first_name TEXT NOT NULL,
    customer_last_name TEXT NOT NULL,
    phone_mobile TEXT,
    phone_landline TEXT, -- Für Telekom erweitert
    email TEXT,
    street TEXT,
    postal_code TEXT,
    city TEXT,

    -- VERSICHERUNGS-FELDER (NUR department_id = 1)
    -- Versicherungsbedarf (Checkboxen)
    need_kvg INTEGER DEFAULT 0,
    need_vvg INTEGER DEFAULT 0,
    need_auto INTEGER DEFAULT 0,
    need_lv INTEGER DEFAULT 0,  -- Lebensversicherung
    need_hr INTEGER DEFAULT 0,  -- Hausrat
    need_rs INTEGER DEFAULT 0,  -- Rechtsschutz
    need_ph INTEGER DEFAULT 0,  -- Privathaftpflicht

    -- Versicherungsgesellschaften (Top 20 CH)
    kvg_company TEXT, -- Top 20 Krankenversicherungen
    vvg_company TEXT,
    auto_company TEXT,
    lv_company TEXT,
    hr_company TEXT,
    rs_company TEXT,
    ph_company TEXT,

    -- Versicherungsdetails
    franchise INTEGER, -- 300, 500, 1000, 1500, 2000, 2500 CHF
    premium_monthly DECIMAL(10,2),
    contract_year INTEGER,

    -- Gesundheitsfragen (bei KVG/VVG)
    in_treatment INTEGER DEFAULT 0,
    takes_medication INTEGER DEFAULT 0,
    had_surgery_5years INTEGER DEFAULT 0,

    -- TELEKOM-FELDER (NUR department_id = 2)
    has_vorvertraege INTEGER DEFAULT 0,
    vorvertraege_count INTEGER DEFAULT 0,
    vorvertraege_details TEXT,
    has_ret INTEGER DEFAULT 0,
    ret_count INTEGER DEFAULT 0,
    ret_details TEXT,

    -- MANAGEMENT-FELDER (NUR für Root/Lead bei Versicherung)
    status TEXT, -- NULL für Telekom, Pendent/Stattgefunden/Abgesagt für Versicherung
    deal_count INTEGER, -- NULL für Telekom
    contract_start DATE, -- NEU! Vertragsbeginn-Datum

    -- ALLGEMEINE FELDER
    priority TEXT DEFAULT 'normal',
    notes TEXT,

    -- METADATEN
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,

    -- FOREIGN KEYS
    FOREIGN KEY (agent_id) REFERENCES users(id),
    FOREIGN KEY (created_by_id) REFERENCES users(id),
    FOREIGN KEY (team_id) REFERENCES teams(id),
    FOREIGN KEY (department_id) REFERENCES departments(id)
);

-- Index für Performance
CREATE INDEX idx_appointments_agent_id ON appointments(agent_id);
CREATE INDEX idx_appointments_date ON appointments(date);
CREATE INDEX idx_appointments_department ON appointments(department_id);
CREATE INDEX idx_appointments_team_id ON appointments(team_id);
CREATE INDEX idx_appointments_status ON appointments(status);

-- 6. FAMILY_MEMBERS (Familienmitglieder - NUR für Versicherung)
CREATE TABLE family_members (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    appointment_id INTEGER NOT NULL,
    first_name TEXT NOT NULL,
    last_name TEXT NOT NULL,
    birth_date DATE,
    relationship TEXT NOT NULL, -- Ehepartner, Kind, Elternteil, Geschwister, Sonstiges
    phone TEXT,
    email TEXT,
    notes TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (appointment_id) REFERENCES appointments(id) ON DELETE CASCADE
);

-- Index für Familienmitglieder
CREATE INDEX idx_family_members_appointment ON family_members(appointment_id);

-- 7. APPOINTMENT_EXPORTS (Export-Verlauf)
CREATE TABLE appointment_exports (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    appointment_id INTEGER NOT NULL,
    user_id INTEGER NOT NULL,
    export_type TEXT NOT NULL, -- 'excel' oder 'pdf'
    file_name TEXT NOT NULL,
    file_size INTEGER,
    export_status TEXT DEFAULT 'completed', -- completed, failed
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (appointment_id) REFERENCES appointments(id),
    FOREIGN KEY (user_id) REFERENCES users(id)
);

-- 8. USER_ACTIVITIES (Benutzer-Aktivitäten)
CREATE TABLE user_activities (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    activity_type TEXT NOT NULL, -- login, logout, create_appointment, etc.
    activity_data TEXT, -- JSON mit Details
    ip_address TEXT,
    user_agent TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
);

-- 9. TEAM_TARGETS (Team-Ziele und Performance)
CREATE TABLE team_targets (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    team_id INTEGER NOT NULL,
    year INTEGER NOT NULL,
    month INTEGER NOT NULL,
    target_appointments INTEGER DEFAULT 0,
    target_deals INTEGER DEFAULT 0,
    actual_appointments INTEGER DEFAULT 0,
    actual_deals INTEGER DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (team_id) REFERENCES teams(id),
    UNIQUE(team_id, year, month)
);

-- 10. SYSTEM_SETTINGS (System-Konfiguration)
CREATE TABLE system_settings (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    setting_key TEXT NOT NULL UNIQUE,
    setting_value TEXT,
    setting_type TEXT DEFAULT 'string', -- string, number, boolean, json
    description TEXT,
    is_public INTEGER DEFAULT 0, -- 0 = nur Admin, 1 = alle Benutzer
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Standard-Einstellungen
INSERT INTO system_settings (setting_key, setting_value, setting_type, description, is_public) VALUES
('app_name', 'TermineCRM v8.0 Enterprise', 'string', 'Anwendungsname', 1),
('app_version', '8.0', 'string', 'Version', 1),
('default_language', 'de', 'string', 'Standard-Sprache', 1),
('session_timeout_days', '7', 'number', 'Session-Timeout in Tagen', 0),
('max_export_file_size_mb', '10', 'number', 'Maximale Export-Dateigröße', 0),
('enable_notifications', 'true', 'boolean', 'Benachrichtigungen aktivieren', 1);

-- 11. NOTIFICATION_LOGS (Benachrichtigungs-Verlauf)
CREATE TABLE notification_logs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    notification_type TEXT NOT NULL, -- appointment_reminder, export_ready, etc.
    title TEXT NOT NULL,
    message TEXT NOT NULL,
    is_read INTEGER DEFAULT 0,
    priority TEXT DEFAULT 'normal', -- low, normal, high
    metadata TEXT, -- JSON mit zusätzlichen Daten
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    read_at DATETIME,
    FOREIGN KEY (user_id) REFERENCES users(id)
);

-- 12. PERFORMANCE_METRICS (Performance-Metriken für Dashboard)
CREATE TABLE performance_metrics (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    team_id INTEGER,
    department_id INTEGER,
    metric_date DATE NOT NULL,
    appointments_created INTEGER DEFAULT 0,
    appointments_completed INTEGER DEFAULT 0,
    deals_closed INTEGER DEFAULT 0,
    revenue_generated DECIMAL(10,2) DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (team_id) REFERENCES teams(id),
    FOREIGN KEY (department_id) REFERENCES departments(id),
    UNIQUE(user_id, metric_date)
);

-- Index für Performance-Metriken
CREATE INDEX idx_performance_date ON performance_metrics(metric_date);
CREATE INDEX idx_performance_user ON performance_metrics(user_id);
CREATE INDEX idx_performance_team ON performance_metrics(team_id);

-- 13. AUDIT_TRAIL (Audit-Trail für Compliance)
CREATE TABLE audit_trail (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    table_name TEXT NOT NULL,
    record_id INTEGER,
    action TEXT NOT NULL, -- CREATE, UPDATE, DELETE
    old_values TEXT, -- JSON
    new_values TEXT, -- JSON
    ip_address TEXT,
    user_agent TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
);

-- ====================================================================
-- VIEWS für bessere Performance
-- ====================================================================

-- View: Appointment mit User- und Team-Details
CREATE VIEW v_appointments_detailed AS
SELECT 
    a.*,
    u.name as agent_name,
    u.email as agent_email,
    t.name as team_name,
    d.name as department_name,
    d.color as department_color,
    creator.name as created_by_name,
    -- Familienmitglieder-Anzahl (nur für Versicherung)
    CASE 
        WHEN a.department_id = 1 THEN (
            SELECT COUNT(*) FROM family_members fm WHERE fm.appointment_id = a.id
        )
        ELSE 0
    END as family_members_count
FROM appointments a
LEFT JOIN users u ON a.agent_id = u.id
LEFT JOIN users creator ON a.created_by_id = creator.id
LEFT JOIN teams t ON a.team_id = t.id
LEFT JOIN departments d ON a.department_id = d.id;

-- View: Team-Performance
CREATE VIEW v_team_performance AS
SELECT 
    t.id as team_id,
    t.name as team_name,
    d.name as department_name,
    COUNT(DISTINCT u.id) as team_members_count,
    COUNT(a.id) as total_appointments,
    COUNT(CASE WHEN a.date = DATE('now') THEN 1 END) as appointments_today,
    COUNT(CASE WHEN a.date >= DATE('now', 'weekday 0', '-6 days') THEN 1 END) as appointments_this_week,
    COALESCE(SUM(a.deal_count), 0) as total_deals,
    ROUND(
        CASE 
            WHEN COUNT(a.id) > 0 
            THEN (COALESCE(SUM(a.deal_count), 0) * 100.0 / COUNT(a.id))
            ELSE 0
        END, 2
    ) as success_rate
FROM teams t
LEFT JOIN departments d ON t.department_id = d.id
LEFT JOIN users u ON u.team_id = t.id AND u.is_active = 1
LEFT JOIN appointments a ON a.team_id = t.id
WHERE t.is_active = 1
GROUP BY t.id, t.name, d.name;

-- View: User-Performance
CREATE VIEW v_user_performance AS
SELECT 
    u.id as user_id,
    u.name as user_name,
    u.role,
    t.name as team_name,
    d.name as department_name,
    COUNT(a.id) as total_appointments,
    COUNT(CASE WHEN a.date = DATE('now') THEN 1 END) as appointments_today,
    COUNT(CASE WHEN a.date >= DATE('now', 'weekday 0', '-6 days') THEN 1 END) as appointments_this_week,
    COALESCE(SUM(a.deal_count), 0) as total_deals,
    ROUND(
        CASE 
            WHEN COUNT(a.id) > 0 
            THEN (COALESCE(SUM(a.deal_count), 0) * 100.0 / COUNT(a.id))
            ELSE 0
        END, 2
    ) as success_rate
FROM users u
LEFT JOIN teams t ON u.team_id = t.id
LEFT JOIN departments d ON u.department_id = d.id
LEFT JOIN appointments a ON a.agent_id = u.id
WHERE u.is_active = 1
GROUP BY u.id, u.name, u.role, t.name, d.name;

-- ====================================================================
-- TRIGGERS für automatische Updates
-- ====================================================================

-- Trigger: Update updated_at bei Änderungen
CREATE TRIGGER trg_users_updated_at 
AFTER UPDATE ON users
BEGIN
    UPDATE users SET updated_at = CURRENT_TIMESTAMP WHERE id = NEW.id;
END;

CREATE TRIGGER trg_appointments_updated_at 
AFTER UPDATE ON appointments
BEGIN
    UPDATE appointments SET updated_at = CURRENT_TIMESTAMP WHERE id = NEW.id;
END;

CREATE TRIGGER trg_teams_updated_at 
AFTER UPDATE ON teams
BEGIN
    UPDATE teams SET updated_at = CURRENT_TIMESTAMP WHERE id = NEW.id;
END;

-- Trigger: Audit Trail
CREATE TRIGGER trg_appointments_audit_update
AFTER UPDATE ON appointments
BEGIN
    INSERT INTO audit_trail (
        user_id, table_name, record_id, action, 
        old_values, new_values, created_at
    ) VALUES (
        NEW.agent_id, 'appointments', NEW.id, 'UPDATE',
        json_object(
            'status', OLD.status,
            'deal_count', OLD.deal_count,
            'updated_at', OLD.updated_at
        ),
        json_object(
            'status', NEW.status,
            'deal_count', NEW.deal_count,
            'updated_at', NEW.updated_at
        ),
        CURRENT_TIMESTAMP
    );
END;

-- ====================================================================
-- PERFORMANCE OPTIMIERUNGEN
-- ====================================================================

-- Weitere Indizes für häufige Queries
CREATE INDEX idx_users_role ON users(role);
CREATE INDEX idx_users_department ON users(department_id);
CREATE INDEX idx_users_team ON users(team_id);
CREATE INDEX idx_users_active ON users(is_active);

CREATE INDEX idx_sessions_user_id ON sessions(user_id);
CREATE INDEX idx_sessions_expires ON sessions(expires_at);

CREATE INDEX idx_appointments_created_by ON appointments(created_by_id);
CREATE INDEX idx_appointments_priority ON appointments(priority);

-- Composite Indizes für Dashboard-Queries
CREATE INDEX idx_appointments_date_agent ON appointments(date, agent_id);
CREATE INDEX idx_appointments_date_team ON appointments(date, team_id);
CREATE INDEX idx_appointments_dept_status ON appointments(department_id, status);

-- ====================================================================
-- CONSTRAINTS und VALIDIERUNGEN
-- ====================================================================

-- Check Constraints (simuliert durch Triggers)
CREATE TRIGGER trg_validate_user_role
BEFORE INSERT ON users
BEGIN
    SELECT CASE
        WHEN NEW.role NOT IN ('root', 'lead', 'agent') THEN
            RAISE(ABORT, 'Invalid role. Must be: root, lead, or agent')
    END;
END;

CREATE TRIGGER trg_validate_appointment_status
BEFORE UPDATE ON appointments
BEGIN
    SELECT CASE
        WHEN NEW.status IS NOT NULL AND NEW.status NOT IN ('pendent', 'stattgefunden', 'abgesagt') THEN
            RAISE(ABORT, 'Invalid status. Must be: pendent, stattgefunden, or abgesagt')
    END;
END;

-- ====================================================================
-- DATENINTEGRITÄT
-- ====================================================================

-- Foreign Key Constraints werden automatisch durch FOREIGN KEY definiert
-- Zusätzliche Integrität durch Application Logic in der API

-- ====================================================================
-- SCHEMA VERSION TRACKING
-- ====================================================================

INSERT INTO system_settings (setting_key, setting_value, setting_type, description) VALUES
('schema_version', '8.0', 'string', 'Database Schema Version'),
('schema_created', datetime('now'), 'string', 'Schema Creation Date'),
('last_migration', datetime('now'), 'string', 'Last Migration Date');

-- ====================================================================
-- ENDE DES SCHEMAS
-- ====================================================================

-- HINWEIS: Dieses Schema wird über die API automatisch erstellt.
-- Die Worker-API erstellt Tabellen bei Bedarf und migriert bestehende Daten.
-- Manuelle Ausführung dieser SQL-Befehle ist NICHT erforderlich und 
-- könnte bestehende Daten zerstören.

-- Version: 8.0 Enterprise
-- Unterstützt: Abteilungsspezifische Formulare, Familienmitglieder,
--              Erweiterte KPIs, Export-Funktionen, Audit-Trail
